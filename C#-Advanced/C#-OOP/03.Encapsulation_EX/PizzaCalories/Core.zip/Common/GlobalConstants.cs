﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCalories.Common
{
    public static class GlobalConstants
    {
        public const double baseCalories = 2;
    }
}
